declare module 'node-pagerduty';
