---
name: "\U0001F41B Bug report"
about: Report a bug for this project
title: ''
labels: ''
assignees: ''

---

## Expected Behavior

<!-- Tell us what should happen -->

## Current Behavior

<!-- Tell us what happens instead of the expected behavior -->

## Steps to Reproduce

<!-- Provide a link to a live example, or an unambiguous set of steps to reproduce this bug. -->
<!-- Include code to reproduce, if relevant -->

## Environment

- OS:

<!-- Put your dotenv within backticks below. Be sure to remove any secrets/passwords. -->
```dotenv
```

## Logs

<!-- Provide a brief log -->
