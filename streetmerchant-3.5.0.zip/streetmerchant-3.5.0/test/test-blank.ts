import * as assert from 'assert';

assert.strictEqual(true, true);
